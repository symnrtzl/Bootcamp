package Kodlama.io.Devs.KodlamaHomework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KodlamaHomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(KodlamaHomeworkApplication.class, args);
	}

}
