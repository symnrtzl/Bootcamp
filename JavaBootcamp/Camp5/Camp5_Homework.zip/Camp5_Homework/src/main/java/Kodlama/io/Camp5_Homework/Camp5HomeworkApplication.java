package Kodlama.io.Camp5_Homework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Camp5HomeworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(Camp5HomeworkApplication.class, args);
	}

}
