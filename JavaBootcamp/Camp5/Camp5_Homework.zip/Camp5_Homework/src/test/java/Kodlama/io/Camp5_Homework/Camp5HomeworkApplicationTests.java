package Kodlama.io.Camp5_Homework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Camp5HomeworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
